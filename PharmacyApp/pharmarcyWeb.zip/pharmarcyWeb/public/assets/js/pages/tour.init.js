/**
 * Theme: Tailfox - Tailwind Admin Dashboard Template
 * Author: Mannatthemes
 * Tour Js
 */
!function(){var t={id:"welcome_tour",steps:[{title:"FAQ",content:"Have you any quetion?",target:"#tourFaq",placement:"top"},{title:"Exellent Master Plan",content:"This is the pricing cards.",target:document.querySelector("#Pricing_Card"),placement:"top"}],showPrevButton:!0,scrollTopMargin:100};hopscotch.startTour(t)}();